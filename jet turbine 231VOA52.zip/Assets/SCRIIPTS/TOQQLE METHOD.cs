using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleMethod : MonoBehaviour
{
    public GameObject jetCompnenet;
    private bool isVisible = true;

    public void Toggle()
    {
        if (isVisible)
        {
            jetCompnenet.SetActive(false);
            isVisible = false;
        }
        else
        {
            jetCompnenet.SetActive(true);
            isVisible = true;
        }
    }
}
